# Pangpang Island Backend (Render-ready)

See .env.example for required environment variables.

Endpoints:
- /api/auth
- /api/bookings
- /api/rooms
- /api/payments
- /api/admin
- /api/images
